<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Create Book
                    <a class="nav-link float-right" href="<?php echo e(url('/book')); ?>"><?php echo e(__('View All Book')); ?></a>
                </div>
                
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(url('book')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Book Title')); ?></label>

                            <div class="col-md-6">
                                <input id="title" type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title" value="<?php echo e(old('title')); ?>" required autocomplete="title" autofocus>

                                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="author" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Author')); ?></label>

                            <div class="col-md-6">
                                <input id="author" type="text" class="form-control <?php if ($errors->has('author')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('author'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="author" value="<?php echo e(old('author')); ?>" required autocomplete="author" autofocus>

                                <?php if ($errors->has('author')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('author'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="price" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Daily Price')); ?></label>

                            <div class="col-md-6">
                                <input id="price" type="text" class="form-control <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="price" value="<?php echo e(old('price')); ?>" required autocomplete="price" autofocus>

                                <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Submit')); ?>

                                </button>
                            </div>
                        </div>
                            
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amose\OneDrive\Documents\Research\digitize\lendingBookSystem\resources\views/book/create.blade.php ENDPATH**/ ?>