<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-6">
     <div class="form-group">
      <label>Tgl Awal</label>
      <div class="input-group date">
       <div class="input-group-addon">
              <span class="glyphicon glyphicon-th"></span>
          </div>
          <input placeholder="masukkan tanggal Awal" type="text" class="form-control datepicker" name="tgl_awal">
      </div>
     </div>
     <div class="form-group">
      <label>Tgl Akhir</label>
      <div class="input-group date">
       <div class="input-group-addon">
              <span class="glyphicon glyphicon-th"></span>
          </div>
          <input placeholder="masukkan tanggal Akhir" type="text" class="form-control datepicker" name="tgl_akhir">
      </div>
     </div>
    </div>
   </div>

   <script type="text/javascript">
    $(function(){
     $(".datepicker").datepicker({
         format: 'yyyy-mm-dd',
         autoclose: true,
         todayHighlight: true,
     });
    });
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amose\OneDrive\Documents\Research\digitize\lendingBookSystem\resources\views/transaction/index.blade.php ENDPATH**/ ?>