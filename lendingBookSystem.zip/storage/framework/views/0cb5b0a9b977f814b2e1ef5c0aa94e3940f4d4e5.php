<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">View All Book
                    <?php if(Auth::user()->admin == 1): ?>
                    <a class="nav-link float-right" href="<?php echo e(url('/book/create')); ?>"><?php echo e(__('Add Book')); ?></a>
                    <?php else: ?>
                    <?php endif; ?>
                </div>
                

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>

                    <table border="2">
                        <tr>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>Daily Price</th>
                            <th>Book Count</th>
                            <?php if(Auth::user()->admin == 1): ?>
                            <th>Option</th>
                            <?php endif; ?>
                        </tr>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($book->title); ?></td>
                            <td><?php echo e($book->author); ?></td>
                            <td><?php echo e($book->price); ?></td>
                            <td><?php echo e($book->count); ?></td>
                            <?php if(Auth::user()->admin == 1): ?>
                            <td>
                                <a href="<?php echo e(route('book.edit', $book->id)); ?>" class="btn btn-primary">Edit</a>
                                |
                                <form action="<?php echo e(route('book.destroy', $book->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                            <?php else: ?>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amose\OneDrive\Documents\Research\digitize\lendingBookSystem\resources\views/book/index.blade.php ENDPATH**/ ?>